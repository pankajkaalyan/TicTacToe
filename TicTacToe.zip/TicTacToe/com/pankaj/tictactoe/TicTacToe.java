package com.pankaj.tictactoe;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class TicTacToe {
	
	private static JPanel jPanel = null;
	private JPanel jPanel2 = null;
	private JFrame jFrame = null;
	private BufferedImage myPicture = null;
	private BufferedImage zero = null;
	private BufferedImage cross = null;
	private GridLayout gridLayout = null;
	private URL url = null;
	private ImageIcon icon = null;
	private ImageIcon img = null;
	private Container cp = null;
	private static  String turn = "USER";
	private static ImageIcon zero_icon = null;
	private static ImageIcon cross_icon = null;
	private static int count = 0;
	private static boolean flag = false;
	
	public static void main(String[] args) {
		new TicTacToe().getGUI();
	}
	
	private void getGUI(){
		jFrame = new JFrame("Tic Tac Toe");
		url = TicTacToe.class.getResource("/Resources/tictactoe.png");
		img = new ImageIcon(url);
		jFrame.setIconImage(img.getImage());
		jFrame.setSize(300,300);

		jPanel = new JPanel();
		jPanel.setBackground(Color.WHITE);
		jPanel.setBorder(BorderFactory.createMatteBorder(10, 10, 10, 10,Color.decode("#009999")));
		
		gridLayout = new GridLayout(3,3,3,3);
		jPanel.setLayout(gridLayout);
	
		try {
			myPicture = ImageIO.read(TicTacToe.class.getResource("/Resources/bg.png"));
			zero = ImageIO.read(TicTacToe.class.getResource("/Resources/zero.png"));
			cross = ImageIO.read(TicTacToe.class.getResource("/Resources/cross2.png"));
		} catch (IOException e) {
			System.err.println("Something went wrong!!");
		}
		icon = new ImageIcon(myPicture);
		cross_icon = new ImageIcon(cross);
		zero_icon = new ImageIcon(zero);
		JLabel picLabel1 = new JLabel(icon);
		picLabel1.setName("1");
		JLabel picLabel2 = new JLabel(icon);
		picLabel2.setName("2");
		JLabel picLabel3 = new JLabel(icon);
		picLabel3.setName("3");
		JLabel picLabel4 = new JLabel(icon);
		picLabel4.setName("4");
		JLabel picLabel5 = new JLabel(icon);
		picLabel5.setName("5");
		JLabel picLabel6 = new JLabel(icon);
		picLabel6.setName("6");
		JLabel picLabel7 = new JLabel(icon);
		picLabel7.setName("7");
		JLabel picLabel8 = new JLabel(icon);
		picLabel8.setName("8");
		JLabel picLabel9 = new JLabel(icon);
		picLabel9.setName("9");
		
		
		jPanel.add(picLabel1);
		jPanel.add(picLabel2);
		jPanel.add(picLabel3);
		jPanel.add(picLabel4);
		jPanel.add(picLabel5);
		jPanel.add(picLabel6);
		jPanel.add(picLabel7);
		jPanel.add(picLabel8);
		jPanel.add(picLabel9);

		JButton resetButton = new JButton(new ImageIcon(TicTacToe.class.getResource("/Resources/reset.png")));
		resetButton.setBackground(Color.decode("#009999"));
		resetButton.setVisible(true);

		jPanel2 = new JPanel();
		jPanel2.setBorder(BorderFactory.createTitledBorder("Reset"));
		jPanel2.add(resetButton);

	    cp = jFrame.getContentPane();
	    cp.setLayout(new BorderLayout());
	    cp.add(jPanel, BorderLayout.CENTER);
	    cp.add(jPanel2, BorderLayout.PAGE_END);
	      
		jFrame.setResizable(false);
		jFrame.setVisible(true);
		jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		picLabel1.addMouseListener(mouseListener);
		picLabel2.addMouseListener(mouseListener);
		picLabel3.addMouseListener(mouseListener);
		picLabel4.addMouseListener(mouseListener);
		picLabel5.addMouseListener(mouseListener);
		picLabel6.addMouseListener(mouseListener);
		picLabel7.addMouseListener(mouseListener);
		picLabel8.addMouseListener(mouseListener);
		picLabel9.addMouseListener(mouseListener);
		resetButton.addActionListener(actionListener);

	}
	
	private ActionListener actionListener = new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent event) {
			reset();
		}
	};
	
	private MouseListener mouseListener = new MouseListener() {
		
		@Override
		public void mouseReleased(MouseEvent e){
		}		
		@Override
		public void mousePressed(MouseEvent e) {	
		}		
		@Override
		public void mouseExited(MouseEvent e) {
		}		
		@Override
		public void mouseEntered(MouseEvent e) {	
		}

		@Override
		public void mouseClicked(MouseEvent e) {
			JLabel l = (JLabel) e.getSource();
			
			if(l.getIcon()!=cross_icon && l.getIcon()!=zero_icon && !flag){
				if(turn.equalsIgnoreCase("USER")){
				l.setIcon(cross_icon);
				l.setName("User");
				turn="AI";
				
				
				flag = checkResult() ? true :false;
				
				
				}else{
				l.setIcon(zero_icon);
				l.setName("AI");
				turn="USER";
				 
				
				flag = checkResult() ? true :false;
				
				
				}
				if(flag){
					int response = 0; 
					if(turn.equals("AI")){
						response = JOptionPane.showOptionDialog(null, "PLAYER 1 WON. DO YOU WANT TO PLAY AGAIN!!", "Game Over", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE, null, null, null);
						playAgain(response);
					}
					else{
						response = JOptionPane.showOptionDialog(null, "PLAYER 2 WON. DO YOU WANT TO PLAY AGAIN!!", "Game Over", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE, null, null, null);
						playAgain(response);
					}
				}
				
				if(count==9 && !flag){
						int tied = JOptionPane.showOptionDialog(null, "GAME TIED. DO YOU WANT TO PLAY AGAIN!!", "Game Over", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE, null, null, null);
						playAgain(tied);
				}
				
			}else{
				if(flag)
					System.out.println("Game Over!!");
				else
					System.out.println("Please select another");
			}
			
		}
	};
	
	public static boolean rowCrossed(){
		
		Component[] jCom = jPanel.getComponents();
		for(Component l:jCom){
			System.out.println(l.getName());
		}
		if((((JLabel)jCom[0]).getName() == ((JLabel) jCom[1]).getName() && ((JLabel)jCom[0]).getName() == ((JLabel) jCom[2]).getName()) ||
				(((JLabel)jCom[3]).getName() == ((JLabel) jCom[4]).getName() && ((JLabel)jCom[3]).getName() == ((JLabel) jCom[5]).getName()) ||
					(((JLabel)jCom[6]).getName() == ((JLabel) jCom[7]).getName() && ((JLabel)jCom[6]).getName() == ((JLabel) jCom[8]).getName())){
			return true;
		}
		return false;
	}
	
	public static boolean columnCrossed(){
		
		Component[] jCom = jPanel.getComponents();
		for(Component l:jCom){
			System.out.println(l.getName());
		}
		if((((JLabel)jCom[0]).getName() == ((JLabel) jCom[3]).getName() && ((JLabel)jCom[0]).getName() == ((JLabel) jCom[6]).getName()) ||
				(((JLabel)jCom[1]).getName() == ((JLabel) jCom[4]).getName() && ((JLabel)jCom[1]).getName() == ((JLabel) jCom[7]).getName()) ||
					(((JLabel)jCom[2]).getName() == ((JLabel) jCom[5]).getName() && ((JLabel)jCom[2]).getName() == ((JLabel) jCom[8]).getName())){
			return true;
		}
		return false;
	}
	
	public static boolean diagonalCrossed(){
		
		Component[] jCom = jPanel.getComponents();
		for(Component l:jCom){
			System.out.println(l.getName());
		}
		if((((JLabel)jCom[0]).getName() == ((JLabel) jCom[4]).getName() && ((JLabel)jCom[0]).getName() == ((JLabel) jCom[8]).getName()) ||
				(((JLabel)jCom[2]).getName() == ((JLabel) jCom[4]).getName() && ((JLabel)jCom[2]).getName() == ((JLabel) jCom[6]).getName())){
			return true;
		}
		return false;
	}
	
	public static boolean checkResult(){
		if(count++>=4)
			return rowCrossed() ? true : columnCrossed() ? true : diagonalCrossed();
		else
			return false;
	}
	
	public void playAgain(int response){
		if(response == JOptionPane.YES_NO_OPTION)
			reset();
		else
			exit();
	}
	public void reset(){
			jFrame.dispose();
			getGUI();
			flag=false;
			count=0;
	}
	public void exit(){
		jFrame.dispose();
	}
}
